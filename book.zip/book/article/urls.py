from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('article/<slug:slug>', views.article_details, name="article_details"),
    path('category/<slug:slug>', views.single_acticles, name="single_acticles"),
    path('gallery', views.gallery, name="gallery"),
    path('contact', views.contact, name="contact"),
]
