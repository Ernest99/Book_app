from django.contrib import admin
from .models import Author, Category, Article, Comment, ContactMessage, Daily_Post, Gallery

admin.site.site_title = "Augustine LeMaire"
admin.site.site_header = "Augustine LeMaire Dashboard"

# Inline for Comments on the Article admin page
class CommentInline(admin.TabularInline):
    model = Comment
    extra = 1
    readonly_fields = ('full_name', 'email', 'comment', 'is_offensive')
    can_delete = True
    fields = ('full_name', 'email', 'comment', 'is_offensive')

# Custom admin for Article
class ArticleAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'category', 'date_created', 'updated_on')
    search_fields = ('title', 'author__user__username', 'category__name')
    list_filter = ('category', 'date_created', 'updated_on')
    readonly_fields = ('slug',)
    inlines = [CommentInline]
    actions = ['approve_offensive_comments']

    def approve_offensive_comments(self, request, queryset):
        queryset.update(is_offensive=False)
    approve_offensive_comments.short_description = "Approve selected offensive comments"

# Custom admin for Author
class AuthorAdmin(admin.ModelAdmin):
    list_display = ('user', 'phone_number', 'location')
    search_fields = ('user__username', 'phone_number', 'location')

# Custom admin for Category
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'date_created')
    search_fields = ('name',)
    list_filter = ('date_created',)

# Custom admin for Comment
class CommentAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'article', 'email', 'is_offensive')
    search_fields = ('full_name', 'email', 'article__title')
    list_filter = ('is_offensive', 'article__category')
    actions = ['disapprove_comments']

    def disapprove_comments(self, request, queryset):
        queryset.update(is_offensive=True)
    disapprove_comments.short_description = "Disapprove selected comments"

# Custom admin for ContactMessage
class ContactMessageAdmin(admin.ModelAdmin):
    list_display = ('name', 'email', 'subject', 'message')
    search_fields = ('name', 'email', 'subject')
    
class DailyPostAdmin(admin.ModelAdmin):
    list_display = ('content', 'date_created')
    search_fields = ('content', 'date_created')

class GalleryAdmin(admin.ModelAdmin):
    list_display = ('title', 'image', 'date_created')
    search_fields = ('title', 'image', 'date_created')
    


# Registering the models
admin.site.register(Author, AuthorAdmin)
admin.site.register(Category, CategoryAdmin)
admin.site.register(Article, ArticleAdmin)
admin.site.register(Comment, CommentAdmin)
admin.site.register(ContactMessage, ContactMessageAdmin)
admin.site.register(Daily_Post, DailyPostAdmin)
admin.site.register(Gallery, GalleryAdmin)


