from django.core.paginator import Paginator
from django.shortcuts import render, redirect
from .models import *
from . utils import alert

def index(request):
    article_list = Article.objects.all().order_by('-id')
    paginator = Paginator(article_list, 6)

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    latest_single_article = article_list.first()

    # Get the latest Daily_Post
    latest_daily_post = Daily_Post.objects.order_by('-date_created').first()

    if latest_daily_post:
        words = latest_daily_post.content.split()
        daily_post_content_parts = [' '.join(words[i:i+6]) for i in range(0, len(words), 6)]
    else:
        daily_post_content_parts = []

    context = {
        "index_articles": page_obj,
        "latest_single_article": latest_single_article,
        "daily_post_content_parts": daily_post_content_parts,  # Pass to template
    }

    return render(request, 'index.html', context)




def gallery(request):
    galleries = Gallery.objects.all()
    paginator = Paginator(galleries, 8) 

    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    context = {
        "galleries":page_obj
    }
    
    return render(request, 'gallery.html', context)



def single_acticles(request, slug):
    category = Category.objects.get(slug=slug)
    article_list = Article.objects.filter(category=category).order_by('-id')
    paginator = Paginator(article_list, 6) 
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    latest_single_article = article_list.first()
    context = {
        "single_articles": page_obj,
        "latest_single_article": latest_single_article,
        "category": category,
    }
    return render(request, "single_article.html", context)


def article_details(request, slug):
    article = Article.objects.get(slug=slug)
    other_articles = Article.objects.all().order_by('-views')[:4]
    article.views += 1
    article.save()
    
    context = {
        "article":article,
        "other_articles":other_articles
    }
    return render(request, "article_details.html", context)


def contact(request):
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['email']
        subject = request.POST['subject']
        message = request.POST['message']

        contact_message = ContactMessage.objects.create(
            name = name,
            email = email,
            subject = subject,
            message = message,
        )
        contact_message.save()
        alert(request, "success", f"Thanks for contacting me {name}")
        return redirect('contact')
    
    return render(request, 'contact.html')


def error_404(request, exceptions):
    
    return render(request, "404.html")