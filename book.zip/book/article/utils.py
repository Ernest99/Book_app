from izitoast.functions import izitoast

def alert(request, model, message):
    diversify = {
        "position": "topRight",
        "transition_in": "flipInX",
        "transition_out": "flipOutX",
        "time_out": 3000,
    }

    izitoast(request=request, model=model, message=message, diversify=diversify)
