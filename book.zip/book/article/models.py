from django.db import models
from django.contrib.auth.models import User
from django.utils.text import slugify
from django_ckeditor_5.fields import CKEditor5Field
import random
import string

# Author
class Author(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=15)
    # about = RichTextField(null=True, blank=True, 
    #     config_name="special", external_plugin_resources=[(
    #     'youtube', '/static/shareledge/ckeditor-plugins/youtube/youtube/', 'plugin.js',
    # )])
    about = CKEditor5Field('Text', config_name='extends', null=True)
    location = models.CharField(max_length=100)
    
    def __str__(self):
        return self.user.get_full_name()
    
    class Meta:
        db_table = 'authors'
        managed = True
        verbose_name = 'Author'
        verbose_name_plural = 'Authors'


class Category(models.Model):
    name = models.CharField(max_length=100)
    slug = models.SlugField(max_length=100, unique=True, blank=True, null=True)
    date_created = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)

    class Meta:
        db_table = 'categories'
        managed = True
        verbose_name = 'Category'
        verbose_name_plural = 'Categories'

        

class Article(models.Model):
    author = models.ForeignKey(Author, on_delete=models.CASCADE)
    category = models.ForeignKey(Category, on_delete=models.SET_DEFAULT, default="other", null=True)
    title = models.CharField(max_length=500)
    cover = models.ImageField(upload_to="Article_Images", null=True)
    # content = RichTextField(null=True, blank=True, 
    #     config_name="special", external_plugin_resources=[(
    #     'youtube', '/static/shareledge/ckeditor-plugins/youtube/youtube/', 'plugin.js',
    # )])
    content = CKEditor5Field('Text', config_name='extends', null=True)
    slug = models.SlugField(max_length=255, unique=True, editable=False, null=True)
    date_created = models.DateTimeField(auto_now_add=True)
    updated_on = models.DateTimeField(auto_now=True)
    views = models.IntegerField(default=0)
    
    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.title)
            existing_slug = Article.objects.filter(slug=self.slug).exists()
            if existing_slug:
                random_string = ''.join(random.choices(string.ascii_lowercase + string.digits, k=6))
                self.slug = f"{self.slug}-{random_string}"
        super(Article, self).save(*args, **kwargs)
    
    def __str__(self):
        return self.title
    
    class Meta:
        db_table = 'articles'
        managed = True
        verbose_name = 'Article'
        verbose_name_plural = 'Articles'


class Comment(models.Model):
    article = models.ForeignKey(Article,  on_delete=models.CASCADE)
    full_name = models.CharField(max_length=1000)
    email = models.EmailField()
    # comment = RichTextField(null=True, blank=True, 
    #     config_name="special", external_plugin_resources=[(
    #     'youtube', '/static/shareledge/ckeditor-plugins/youtube/youtube/', 'plugin.js',
    # )])
    comment = CKEditor5Field('Text', config_name='extends', null=True)
    is_offensive = models.BooleanField(default=False)
    
    def __str__(self):
        return self.full_name
    
    class Meta:
        db_table = 'comment'
        managed = True
        verbose_name = 'Comment'
        verbose_name_plural = 'Comments'


class ContactMessage(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    subject = models.CharField(max_length=100)
    message = models.TextField(max_length=1000)
    
    def __str__(self):
        return "Message from {}".format(self.name)
    
    class Meta:
        db_table = 'contact_message'
        managed = True
        verbose_name = 'Contact Message'
        verbose_name_plural = 'Contact Messages'
    

class Daily_Post(models.Model):
    content = models.TextField(max_length=200, null=True)
    date_created = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.content

    class Meta:
        db_table = 'daily_post'
        managed = True
        verbose_name = 'Daily Post'
        verbose_name_plural = 'Daily Posts'
    
class Gallery(models.Model):
    title = models.CharField(max_length=120)
    image = models.ImageField(upload_to="Galleries")
    date_created = models.DateTimeField(auto_now_add=True, null=True)
    
    def __str__(self):
        return self.title
    
        
    class Meta:
        db_table = 'gallery'
        managed = True
        verbose_name = 'Gallery'
        verbose_name_plural = 'Galleries'