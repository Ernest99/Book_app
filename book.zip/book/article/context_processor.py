from . models import Article, Category

def get_recommended_articles(request):
    articles = Article.objects.all().order_by('-views')[1:4]
    single_recommended =  Article.objects.all().order_by('-id', '-views').first()
    categories = Category.objects.all()
    context = {
        "articles":articles,
        "single_recommended":single_recommended,
        "categories":categories,
    }
    return context